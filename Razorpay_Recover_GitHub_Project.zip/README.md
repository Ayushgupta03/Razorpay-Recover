# Razorpay Recover — AI Loan Recovery Prototype

An **interactive, static demonstration** of an AI-powered loan recovery concept for the Razorpay x ISB AI PM Build Challenge (Track 2: Recover and Grow with AI).

## What to explore

- **Agent Studio / Lender Overview:** repayment cases, recovery insights, and case actions
- **Cases & Payment Intelligence:** simulated mandate failures, UPI payments, and next-best actions
- **Call Logs & Insights:** a staged Ayush–Maya recording embedded directly in the web page, call transcript, and case summary
- **Promises to Pay:** recorded commitments, overdue follow-through, and illustrative reconciliation
- **Controls:** lender authorisation, contact windows, identity-verification and escalation checks
- **Impact & Holdout:** illustrative funnel and test/control framework for assessing incremental recovery

## Run locally

Open `index.html` in any modern desktop browser. No build, dependency installation, backend, or API credentials are required.

To serve locally with Python instead:

```bash
python3 -m http.server 8000
```

Then open <http://localhost:8000/>.

## Host on GitHub Pages

1. Publish this folder to a **public** GitHub repository called `razorpay-recover`.
2. In the GitHub repository, go to **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select the **main** branch and `/ (root)` folder, then save.
5. GitHub will display the live Pages URL once deployment completes.

## Important notes

- This is a **product concept**, not an official Razorpay product or an authorised Razorpay integration.
- All loans, borrowers, forecasts, outcomes, lender policies, and measurement figures are **synthetic/illustrative**. No claims of achieved recovery lift are made.
- The call recording is a **staged demonstration** and is embedded in `index.html`; hosting this public repository will also publish the recording.
- The interface does not make live calls, trigger real payments, or access lender/borrower records.
- The prototype runs entirely in each visitor's browser; changes are not shared across users or saved on a server.
